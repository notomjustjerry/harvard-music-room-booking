# Jerry Li '26, Wigg B, BioE @Harvard & Film Scoring @Berklee

# RoomBook - Harvard University Music Department

This app allows users to sign out practice rooms using their HarvardKey, eliminating the need for a manual,
physical log of their name, phone number, instrument, etc.

# Running the App

Run this app using VS Code on your PC! At this point, you should have unzipped the file inside a folder.

To run the program, make sure you have `python3` and `pip` installed.

In the terminal, `cd` to the folder this project is contained in. Then, run `cd flask`.
Run `pip install -r requirements.txt` to install the dependencies. Run `flask run`.

Note the terminal output that reads `* Running on http://127.0.0.1:5000`. The app will be served here.

# Using the App

Once you type in the URL above, you should be immediately redirected HarvardKey to login. If this does not
happen, use the Troubleshooting steps at the bottom of the page.

As a new user, you will be prompted to complete a registration profile.

You will then be presented with a page containing a list of available rooms and your user information. Select
a room to sign out, and return the room when complete. You will not be able to sign out another room until you
return the current room.

At any point, click on History to view the complete log history.

For testing purposes, visit `/reset` to delete all logs and users from the database.

# Additional Notes

Note that while the name of the app is "RoomBook", this app does not allow prior reservation of rooms; it
simply substitutes writing in a physical log book.

In the comments and implementation of this app, "booking" a room is synonymous with "signing out" a room.

In the folder `flask` is a .env file. The only variable that should be configured is `TIME_LIMIT`.
This adjusts the maximum time (in minutes, must be an integer) a room can be signed out. After this time, the
room is automatically returned. Per HUMD policy, this is 120 minutes, but for the purposes of demonstration,
this is set to 1 minute. Feel free to change this to 120 minutes for testing.

# Troubleshooting

If the development server (domain) is not http://127.0.0.1:5000, follow these steps:
1. Go to https://id.cs50.io/.
2. Click Log in.
3. Enter anything in the Description
4. Type the domain of the development server into Callback URL(s), followed by /callback. For example, if the
   URL is http://1.1.1.1:5000, type in http://1.1.1.1:5000/callback.
5. In the folder `flask`, open the .env file. Copy the Client ID and Client Secret from https://id.cs50.io into
   their respective environment variables.
6. Rerun `flask run`.

Note that this app does not work with GitHub Codespaces.

If there is an Internal Server Error, or if an error reads "Access to SERVER was denied", open Incognito
(Private Browsing) mode to access the server or visit `/reset`.

# Presentation video

https://www.youtube.com/watch?v=HLqGHkBqckw