# Use of CS50 Finance Template and CS50 ID Sample App, app.py

My project utilizes two templates: the CS50 Finance Problem Set for style, and the CS50 ID Sample Flask
App found here: https://cs50.readthedocs.io/id/. This was a CS50 ID-tailored version of publicly
available sample projects from Auth0. @login_required is from CS50 ID.

# Use of .env, Lines 20-22

One modification I made to the CS50 ID template was incorporating a .env file and the use of the dotenv
libary. This saves users from having to manually export environment variables with each use.

# KEY FEATURE: SQL Database, practice.db

This project uses three SQL database tables, which can be found in `schema.sql` in the `flask` folder.
Using separate tables for users, rooms, and logs, allows for a relational database.

It also provides a key feature: allowing user info to be stored and filled out automatically.

# Registration of new users, Lines 162-177

If a user does not exist yet, users are redirected to a form to fill out additional information.

# Rooms booked directly from homepage, Lines 118-122

Rooms are booked from the homepage for ease of use. This means they don't have to click on a separate
button to get to a booking page.

# KEY FEATURE: Preventing booking of multiple rooms, Lines 112-116

In lines 112 to 116, the program checks if a room has been booked by the user. If so, the user cannot
access the homepage to book another room, and is redirected to `booked.html`. The frequency of this action
justifies the redundancy described below.

# Updating two database tables when a room is signed out or returned, Lines 102-109 and 132-139

When a room is signed out, both the rooms table and logs table are updated (e.g. lines 102-105). While
this may seem redundant, this was far easier to implement than inferring the status of a room from the
logs, every single time the homepage is loaded (to show the list of available rooms).

# Log history, Lines 143-148

The log history page JOINs the users and logs database tables.

# Logout button on the homepage, index.html

Having the logout button on the homepage prevents a user from logging out while a room is signed out,
since the homepage cannot be accessed while a room is signed out.

# KEY FEATURE: Checking expiry of room time, Lines 70-91

Room signouts are limited by the department to 120 minutes. However, this was tricky to implement. JS
Timeouts wouldn't work, since it would restart with every page refresh. Since the server is running
locally, there is no way to automatically check if a room has expired (according to 3 TFs).

Thus, I implemented a function that checks for expired rooms every time a page is loaded. In Lines 76 to
80, it does this by converting timestamps to minutes (timestamps are strings and thus cannot be compared
to each other) and then adding 120 minutes to the sign out timestamp, and checking if the current time has
exceeded this value.

# Timezones, Lines 56-57, 136, etc.

Using the datetime and pytz libraries, timestamps with appropriate timezones were used.

# Jinja and CSS in HTML

The HTML files use Jinja to use a extendable `layout.html`, `for` loops, and `if` conditionals. This data
is passed in when the template is rendered in `app.py`.

Bootstrap and CSS are used through class and ID selectors in HTML files.

# Additional features to be implemented in future iterations

More features that would be included in future iterations of this project include the ability to change
user information and the ability to reserve a room beforehand.

# Presentation video

https://www.youtube.com/watch?v=HLqGHkBqckw