import os
import json
from os import environ as env
from dotenv import find_dotenv, load_dotenv

from authlib.integrations.flask_client import OAuth
from flask import Flask, abort, redirect, render_template, request, session, url_for
from flask_session import Session
from functools import wraps

from cs50 import SQL
from datetime import datetime
from pytz import timezone


# Find the .env file and load the environment variables
ENV_FILE = find_dotenv()
if ENV_FILE:
    load_dotenv(ENV_FILE)

# Check for environment variables
for variable in ["CLIENT_ID", "CLIENT_SECRET", "SERVER_METADATA_URL"]:
    if not env.get(variable):
        abort(500, f"Missing {variable}")

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure OAuth
oauth = OAuth(app)
oauth.register(
    "cs50",
    client_id=os.environ.get("CLIENT_ID"),
    client_kwargs={"scope": "openid profile email"},
    client_secret=os.environ.get("CLIENT_SECRET"),
    server_metadata_url=os.environ.get("SERVER_METADATA_URL")
)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///practice.db")

# Configure time limit for rooms
timeLimit = int(os.environ.get("TIME_LIMIT"))

# Configure timezone
tz = timezone('EST')


# Decorator to require login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("userinfo") is None:
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return decorated_function


# Check if a room sign out has exceeded the maximum time limit
def check_expiry():
    # Identify any logs of rooms that have not been returned yet
    logs = db.execute("SELECT * FROM logs WHERE returntime IS NULL;")

    for log in logs:
        # Convert booking timestamp to minutes
        x = log["booktime"].split()[1].split(":")
        minutes = int(x[0]) * 60 + int(x[1])
        # Convert current timestamp to minutes
        currentMinutes = datetime.now(tz).hour * 60 + datetime.now(tz).minute

        # If current timestamp exceeds booking timestamp plus time limit, return the room
        if currentMinutes > (minutes + timeLimit):
            db.execute("UPDATE rooms SET booked = 0 WHERE id = ?;", log["room_id"])
            db.execute("UPDATE logs SET returntime = ? WHERE username_id = ? AND room_id = ? AND returntime IS NULL",
                        datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S"),
                        session.get("userinfo")["sub"],
                        log["room_id"]
                        )
            return redirect("/")


# Rooms are booked using the homepage
@app.route("/", methods=["GET", "POST"])
@login_required
def index():
    check_expiry()
    if request.method == "POST":
        # Get selected room to sign out
        room = request.form.get("room")
        # Update the rooms database table, set room to be booked
        db.execute("UPDATE rooms SET booked = 1 WHERE id = ?;", room)
        # Update logs
        db.execute("INSERT INTO logs (username_id, room_id, booktime) VALUES (?, ?, ?);",
                   session.get("userinfo")["sub"],
                   room,
                   datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")
                   )
        return render_template("booked.html", room=room)
    else:
        # Get rooms signed out by this user that have not been returned yet
        rows = db.execute("SELECT room_id FROM logs WHERE username_id = ? AND returntime IS NULL;", session.get("userinfo")["sub"])
        # If a room is signed out, redirect to booked page (prevents booking of multiple rooms)
        if len(rows) != 0:
            return render_template("booked.html", room=rows[0]["room_id"])

        # Get user information from database
        userinfo = db.execute("SELECT * FROM users WHERE id = ?", session.get("userinfo")["sub"])
        # Get available rooms
        rooms = db.execute("SELECT * FROM rooms WHERE booked = 0;")
        return render_template("index.html", userinfo=userinfo[0], rooms=rooms)


# Landing after room is returned
@app.route("/returned", methods=["GET", "POST"])
def returned():
    check_expiry()
    if request.method == "POST":
        # Get selected room to return
        room = request.form.get("room")
        # Update rooms database table
        db.execute("UPDATE rooms SET booked = 0 WHERE id = ?;", room)
        # Update logs
        db.execute("UPDATE logs SET returntime = ? WHERE username_id = ? AND room_id = ? AND returntime IS NULL",
                    datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S"),
                    session.get("userinfo")["sub"],
                    room
                    )
    return redirect("/")


# List of logs
@app.route("/history")
def history():
    check_expiry()
    logs = db.execute("SELECT users.name, users.phone, users.email, users.instrument, users.year, logs.room_id, logs.booktime, logs.returntime FROM logs JOIN users ON logs.username_id=users.id ORDER BY booktime DESC;")
    return render_template("history.html", logs=logs)


# Store data from /login in session, send user to /register if new user
@app.route("/callback")
def callback():
    token = oauth.cs50.authorize_access_token()
    session["userinfo"] = oauth.cs50.parse_id_token(token)
    rows = db.execute("SELECT * FROM users WHERE id = ?", session.get("userinfo")["sub"])
    if len(rows) != 1:
        return redirect("/register")
    return redirect(url_for("index"))


# Get additional information not in HarvardKey, e.g. instrument
@app.route("/register", methods=["GET", "POST"])
def register():
    check_expiry()
    if request.method == "POST":
        db.execute("INSERT INTO users (id, name, phone, email, instrument, year) VALUES (?, ?, ?, ?, ?, ?)",
                    session["userinfo"]["sub"],
                    session["userinfo"]["name"],
                    request.form.get("phone"),
                    session["userinfo"]["email"],
                    request.form.get("instrument"),
                    request.form.get("year")
                    )
        return redirect("/")
    else:
        return render_template("register.html")


# Login via CS50 ID
@app.route("/login")
def login():
    session.clear()
    return oauth.cs50.authorize_redirect(redirect_uri=url_for("callback", _external=True))


# Log out
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


# Reset databases for testing purposes
@app.route("/reset")
def reset():
    db.execute("DELETE FROM logs;")
    db.execute("DELETE FROM users;")
    db.execute("UPDATE rooms SET booked = 0;")
    return redirect("/logout")