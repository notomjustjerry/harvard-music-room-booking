CREATE TABLE users
(
    id TEXT PRIMARY KEY NOT NULL, -- UNIQUE
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT NOT NULL,
    instrument TEXT,
    year INTEGER
    -- room_id INTEGER DEFAULT NULL,
    -- FOREIGN KEY(room_id) REFERENCES rooms(id)
    -- HUID? other user attributes?
    -- hash TEXT NOT NULL
);
CREATE UNIQUE INDEX name ON users (name);
CREATE TABLE rooms
(
    id INTEGER PRIMARY KEY NOT NULL,
    type TEXT,
    booked BIT NOT NULL DEFAULT 0
    -- could list attributes of rooms, e.g. size
);
CREATE TABLE logs
(
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    username_id TEXT NOT NULL,
    room_id INTEGER NOT NULL,
    booktime DATETIME NOT NULL,
    returntime DATETIME,
    FOREIGN KEY(username_id) REFERENCES users(id),
    FOREIGN KEY(room_id) REFERENCES rooms(id)
);