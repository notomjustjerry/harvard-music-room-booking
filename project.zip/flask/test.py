# This file is used to populate the rooms database. Replace the list in the for loop and the description in the SQL statement.

from cs50 import SQL

db = SQL("sqlite:///practice.db")

for room in [20]:
    db.execute('INSERT INTO rooms (id, type) VALUES (?, "two grand pianos")', room)

[23, 26, 27, 30, 31, 32, 33, 34, 35]
[24, 25, 28, 29, 36]